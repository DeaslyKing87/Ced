plugins { id("com.android.application") }

android {
    namespace = "com.ced.sharplan"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ced.sharplan"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-diagnostic"
    }
}
