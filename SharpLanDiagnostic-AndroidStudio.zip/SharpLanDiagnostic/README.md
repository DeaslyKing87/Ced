# Sharp LAN Diagnostic
Diagnostic Android app for a Sharp LC-40UI7352E (AQUOS NET+). It deliberately does not assume Roku/Android-TV/US AQUOS protocols.

Features: SSDP discovery, UPnP description/SCPD parsing, manual IP, narrow relevant-port checks, read-only SOAP queries for advertised UPnP services, local logs/share, and locked remote buttons unless a candidate key-control service is advertised.

Research basis: Sharp's LC-40UI7352E datasheet confirms AQUOS NET+, Wi-Fi, DLNA and Miracast. The public user manual documents network setup/AQUOS NET+ but does not document a LAN remote-control API. Therefore this diagnostic proves capabilities on the real TV before any control protocol is claimed.
